import React from 'react'

const IMG = ({link})=>{
    return(
        <img src={link} alt=""  />
    );
}

export default IMG;