
import React from 'react'
import Button from '../components/button';
import IMG from '../components/img';
import Input from '../components/input';

const ChatHistory = ({profile, chathistory}) =>{

    const {imgLink, name, lastSeen} = profile;
    const back  = (<i className="fas fa-chevron-left"></i>)
    const menu = (<i class="fas fa-bars"></i>)
    const send = (<i class="fas fa-paper-plane"></i>)
    return(
        <div className="container">
            <div className="top">
                <div className="left">
                    <div className="back-btn">
                        <Button text={back}/>
                    </div>
                    <IMG link={imgLink}></IMG>
                    <div className="profileinfo">
                        <h3>{name}</h3>
                        <p>{lastSeen}</p>
                    </div>
                </div>
                <div className="option">
                    <Button text={menu}/>
                </div>
            </div>
            <div className="chatHistory">
                
            </div>
            <div className="sendMessage">
                <Input name="message" placeholder="Enter your message.........."/> 
                <Button text={send}/>
            </div>
        </div>
    );
}

export default ChatHistory;