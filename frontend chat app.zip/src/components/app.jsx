import React from 'react'
import { Fragment } from 'react/cjs/react.production.min';
import './assets/style/dashboard.css';
import Sidebar from './layouts/sidebar';
import './assets/style/layout.scss';
import ChatHistory from './layouts/chat';

const App = ({text})=>{
    return(
        <Fragment>
            <div className="dashboard">
                <div className="sidebar">
                    <Sidebar/>
                </div>
                <div className="bashboard">
                     <ChatHistory profile={{ imgLink: 'https://i.pravatar.cc/50',name:'hitesh', lastSeen: "8pm"} } />
                </div>
            </div>
        </Fragment>
    );
}

export default App;